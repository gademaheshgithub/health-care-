# Diabetes Prediction Portal
Diabetes Prediction is my weekend practice project. In this I used KNN Neighbors Classifier to trained model that is used to predict the positive or negative result. Given set of inputs are BMI(Body Mass Index),BP(Blood Pressure),Glucose Level,Insulin Level based on this features it predict whether you have diabetes or not.  

The model is already trained using 768 different types of data.

# Requirements
pycharm,
python 2.7,
sklearn,
numpy,
flask,
json,

Just only Run app.py and open http://127.0.0.1:5000 in your web browser

# ScreenShots of Diabetes Prediction Portal


![Alt text](https://github.com/zikry009/Diabetes_Prediction/blob/master/img/screenshot-127.0.0.1-5000-2019.03.09-16-56-50.png)
# Prediction

![Alt text](https://github.com/zikry009/Diabetes_Prediction/blob/master/img/screenshot-127.0.0.1-5000-2019.03.09-16-57-30.png)
